package com.chensuworks.retrofitweatherservice.retrofit;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/*
 {
    "coord": {
        "lon": -74.01,
        "lat": 40.71
    },
    "weather": [
        {
            "id": 803,
             "main": "Clouds",
             "description": "broken clouds",
             "icon": "04d"
        }
    ],
     "base": "cmc stations",
     "main": {
         "temp": 302.63,
         "pressure": 1014,
         "humidity": 55,
         "temp_min": 300.15,
         "temp_max": 304.85
     },
     "wind": {
         "speed": 3.1
     },
     "clouds": {
         "all": 75
     },
     "dt": 1436375918,
     "sys": {
         "type": 1,
         "id": 1975,
         "message": 0.0133,
         "country": "US",
         "sunrise": 1436347978,
         "sunset": 1436401748
     },
     "id": 5128581,
     "name": "New York",
     "cod": 200
 }
 */
public class WeatherData {

    @SerializedName("coord")
    private Coord mCoord;
    @SerializedName("weather")
    private List<Weather> mWeathers = new ArrayList<Weather>();
    @SerializedName("base")
    private String mBase;
    @SerializedName("main")
    private Main mMain;
    @SerializedName("wind")
    private Wind mWind;
    @SerializedName("clouds")
    private Clouds mClouds;
    @SerializedName("dt")
    private long mDt;
    @SerializedName("sys")
    private Sys mSys;
    @SerializedName("id")
    private long mId;
    @SerializedName("name")
    private String mName;
    @SerializedName("cod")
    private long mCod;

    public WeatherData(Coord coord, List<Weather> weathers, String base, Main main, Wind wind, Clouds clouds, long dt, Sys sys, long id, String name, long cod) {
        mCoord = coord;
        mWeathers = weathers;
        mBase = base;
        mMain = main;
        mWind = wind;
        mClouds = clouds;
        mDt = dt;
        mSys = sys;
        mId = id;
        mName = name;
        mCod = cod;
    }

    public Coord getCoord() { return mCoord; }
    public List<Weather> getWeathers() { return mWeathers; }
    public String getBase() { return mBase; }
    public Main getMain() { return mMain; }
    public Wind getWind() { return mWind; }
    public Clouds getClouds() { return mClouds; }
    public long getDt() { return mDt; }
    public Sys getSys() { return mSys; }
    public long getId() { return mId; }
    public String getName() { return mName; }
    public long getCod() { return mCod; }

    public static class Coord {
        @SerializedName("lon")
        private double mLon;
        @SerializedName("lat")
        private double mLat;

        public Coord(long lon, long lat) {
            mLon = lon;
            mLat = lat;
        }

        public double getLon() { return mLon; }
        public double getLat() { return mLat; }
    }

    public static class Weather {
        @SerializedName("id")
        private long mId;
        @SerializedName("main")
        private String mMain;
        @SerializedName("description")
        private String mDescription;
        @SerializedName("icon")
        private String mIcon;

        public Weather(long id, String main, String description, String icon) {
            mId = id;
            mMain = main;
            mDescription = description;
            mIcon = icon;
        }

        public long getId() { return mId; }
        public String getMain() { return mMain; }
        public String getDescription() { return mDescription; }
        public String getIcon() { return mIcon; }
    }

    public static class Main {
        @SerializedName("temp")
        private double mTemp;
        @SerializedName("humidity")
        private long mHumidity;
        @SerializedName("pressure")
        private double mPressure;
        @SerializedName("temp_min")
        private double mTempMin;
        @SerializedName("temp_max")
        private double mTempMax;

        public Main(double temp, long humidity, double pressure, double tempMin, double tempMax) {
            mTemp = temp;
            mHumidity = humidity;
            mPressure = pressure;
            mTempMin = tempMin;
            mTempMax = tempMax;
        }

        public double getPressure() { return mPressure; }
        public double getTemp() { return mTemp; }
        public long getHumidity() { return mHumidity; }
        public double getTempMin() { return mTempMin; }
        public double getTempMax() { return mTempMax; }
    }

    public static class Wind {
        @SerializedName("speed")
        private double mSpeed;

        public Wind(double speed) {
            mSpeed = speed;
        }

        public double getSpeed() { return mSpeed; }
    }

    public static class Clouds {
        @SerializedName("all")
        private double mAll;

        public Clouds(double all) {
            mAll = all;
        }

        public double getAll() { return mAll; }
    }

    public static class Sys {
        @SerializedName("type")
        private long mType;
        @SerializedName("id")
        private long mId;
        @SerializedName("message")
        private double mMessage;
        @SerializedName("country")
        private String mCountry;
        @SerializedName("sunrise")
        private long mSunrise;
        @SerializedName("sunset")
        private long mSunset;

        public Sys(long type, long id, double message, String country, long sunrise, long sunset) {
            mType = type;
            mId = id;
            mMessage = message;
            mCountry = country;
            mSunrise = sunrise;
            mSunset = sunset;
        }

        public long getType() { return mType; }
        public long getId() { return mId; }
        public double getMessage() { return mMessage; }
        public String getCountry() { return mCountry; }
        public long getSunrise() {
            return mSunrise;
        }
        public long getSunset() { return mSunset; }
    }

}
