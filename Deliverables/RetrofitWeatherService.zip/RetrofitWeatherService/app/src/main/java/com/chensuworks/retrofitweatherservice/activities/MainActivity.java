package com.chensuworks.retrofitweatherservice.activities;

import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.chensuworks.retrofitweatherservice.R;
import com.chensuworks.retrofitweatherservice.retrofit.WeatherData;
import com.chensuworks.retrofitweatherservice.retrofit.WeatherWebServiceProxy;

import retrofit.RestAdapter;


public class MainActivity extends ActionBarActivity {

    private final String TAG = getClass().getSimpleName();

    private WeatherWebServiceProxy mWeatherWebServiceProxy;
    private WeatherData mWeatherData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void getNewYork(View view) {
       new GetWeatherTask().execute("NEWYORK");
    }

    private class GetWeatherTask extends AsyncTask<String, Void, WeatherData> {
        @Override
        protected void onPreExecute() {}

        @Override
        protected WeatherData doInBackground(String... locations) {
            String location = locations[0];

            mWeatherWebServiceProxy = new RestAdapter.Builder()
                    .setEndpoint(WeatherWebServiceProxy.sWeather_Service_URL_Retro)
                    .build()
                    .create(WeatherWebServiceProxy.class);
            mWeatherData = mWeatherWebServiceProxy.getWeatherData(location);

            return mWeatherData;
        }

        @Override
        protected void onPostExecute(WeatherData weatherData) {
            Log.d(TAG, "base = \"" + weatherData.getBase() + "\", " +
                    "dt = " + weatherData.getDt() + "\", " +
                    "id = " + weatherData.getId() + "\", " +
                    "name = \"" + weatherData.getName() + "\", " +
                    "cod = " + weatherData.getCod());
        }

        @Override
        protected void onProgressUpdate(Void... values) {}
    }
}
