package com.chensuworks.retrofitweatherservice.retrofit;

import retrofit.http.GET;
import retrofit.http.Query;

public interface WeatherWebServiceProxy {
    final String sWeather_Service_URL_Retro = "http://api.openweathermap.org/data/2.5";

    @GET("/weather")
    WeatherData getWeatherData(@Query("q") String location);
}

